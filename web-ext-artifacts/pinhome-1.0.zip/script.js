function pinhome() {
    console.log("Listener running");
    browser.tabs.query().then((allTabs) => {
        for (let tab of allTabs) {
            browser.tabs.update(tab.id, {pinned: true});
        }
    });
}

browser.runtime.onStartup.addListener(pinhome);